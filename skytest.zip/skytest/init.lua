local path = minetest.get_modpath("skytest")
dofile(path.."/Craft_Items.lua")
dofile(path.."/Nodes.lua")
dofile(path.."/tools.lua")
dofile(path.."/leaf_press.lua")
dofile(path.."/compost_bin.lua")
dofile(path.."/infused_soil.lua")

